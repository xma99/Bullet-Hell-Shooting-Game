﻿
using var game = new Alpha_Danmaku_Rush_Demo.Game1();
game.Run();
