﻿/*using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Alpha_Danmaku_Rush_Demo

public class Bullet
{
    // Initialize bullet
    public Texture2D bulletSet { get; private set; }
    public Vector2 bulletPosition { get; private set; }
    private Vector2 bulletSpeed;

    public Bullet(Texture2D bulletOne, Vector2 bulletposition, Vector2 bulletspeed)
    {
        bulletSet = bulletOne;
        bulletPosition = bulletposition;
        this.bulletSpeed = bulletspeed;
    }

    // Update bullet position
    public void Update()
    {
        bulletPosition += bulletSpeed;
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(bulletSet, bulletPosition, Color.White);
    }
}*/
