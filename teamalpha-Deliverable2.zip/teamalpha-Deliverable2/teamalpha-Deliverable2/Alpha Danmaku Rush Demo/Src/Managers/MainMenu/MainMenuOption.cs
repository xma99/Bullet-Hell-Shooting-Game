﻿namespace Alpha_Danmaku_Rush_Demo.Src.Managers.MainMenu;

public enum MainMenuOption
{
    ContinueGame,
    NewGame,
    LevelSelection,
    AdjustVolume,
    Exit
}