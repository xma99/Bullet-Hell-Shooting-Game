﻿namespace Alpha_Danmaku_Rush_Demo.Src.Entities.Enemies;

public enum EnemyType
{
    RegularA,
    RegularB,
    MidBoss,
    FinalBoss
}