﻿namespace Alpha_Danmaku_Rush_Demo.Src.Managers;

public class SettingsManager
{
    
}