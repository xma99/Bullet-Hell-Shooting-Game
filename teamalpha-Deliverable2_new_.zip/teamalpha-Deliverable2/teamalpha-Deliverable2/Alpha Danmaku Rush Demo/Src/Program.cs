﻿
using var game = new Alpha_Danmaku_Rush_Demo.Src.Core.Game1();
game.Run();
