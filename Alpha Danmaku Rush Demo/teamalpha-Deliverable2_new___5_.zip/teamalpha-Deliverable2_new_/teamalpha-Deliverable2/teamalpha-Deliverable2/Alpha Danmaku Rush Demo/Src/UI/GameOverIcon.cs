﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Alpha_Danmaku_Rush_Demo.Src.UI
{
    public class GameOverIcon
    {
        private Texture2D gameOverTexture;
        private Vector2 gameOverPosition;

        public GameOverIcon(Texture2D gameOverTexture, Vector2 position)
        {
            this.gameOverTexture = gameOverTexture;
            this.gameOverPosition = position;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(gameOverTexture, gameOverPosition, Color.White);
        }
    }
}
