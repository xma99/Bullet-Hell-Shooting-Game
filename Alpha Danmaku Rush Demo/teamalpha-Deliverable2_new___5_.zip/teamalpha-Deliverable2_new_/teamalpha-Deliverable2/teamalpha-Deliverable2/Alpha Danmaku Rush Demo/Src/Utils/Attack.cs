﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Alpha_Danmaku_Rush_Demo.Src.Utils
{
    public class Attack
    {
        // Fields for enemy properties
        public Texture2D PlayerBullet { get; set; }

        private List<Vector2> bulletPosition;
        public Vector2 BulletVelocity { get; set; } = new Vector2(0, -1);

        public float bulletSpeed = 5.0f;

        public float attackSpeed = 0.2f;

        // private float currentAttack = 0.0f;
        public Vector2 DefaultTarget { get; set; }
        public bool checkAttack { get; set; } = true;

        public int Damage { get; set; } = 1;

        // Enemy attack pattern properties
        // private float attackCooldown;
        // private float currentCooldown;

        // public object BoundingBox { get; internal set; }
        public Attack(ContentManager content)
        {
            PlayerBullet = content.Load<Texture2D>("Bubble");
            bulletPosition = new List<Vector2>();
            BulletVelocity = new Vector2(0, -1);
        }

        // Add Player's bullet in screen
        public void CreateBullet(Vector2 position)
        {
            bulletPosition.Add(position);
        }

        // Adds BoundingBoxe to the player's bullets.
        public List<Rectangle> PlayerBulletBoundingBoxes()
        {
            List<Rectangle> playerBulletList = new List<Rectangle>();

            foreach (var pos in bulletPosition)
            {
                Rectangle bulletBox = new Rectangle((int)pos.X, (int)pos.Y, PlayerBullet.Width, PlayerBullet.Height);
                playerBulletList.Add(bulletBox);
            }
            return playerBulletList;
        }

        public List<Vector2> ActiveBulletsList()
        {
            return new List<Vector2>(bulletPosition);
        }
        public void UpdateAttack(GameTime gameTime)
        {
            // Update bullet positions and remove bullets that leave the screen
            bulletPosition = bulletPosition.Select(pos => pos + BulletVelocity * bulletSpeed).ToList();
            bulletPosition.RemoveAll(pos => pos.Y < -PlayerBullet.Height);
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (Vector2 position in bulletPosition)
            {
                spriteBatch.Draw(PlayerBullet, position, Color.White);
            }
        }
    }
}