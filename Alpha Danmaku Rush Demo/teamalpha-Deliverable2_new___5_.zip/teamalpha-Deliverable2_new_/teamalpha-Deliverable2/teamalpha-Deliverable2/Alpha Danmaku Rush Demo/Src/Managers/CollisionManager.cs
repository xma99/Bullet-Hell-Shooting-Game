﻿using Alpha_Danmaku_Rush_Demo.Src.Entities.Bullet;
using Alpha_Danmaku_Rush_Demo.Src.Entities.Enemies;
using Alpha_Danmaku_Rush_Demo.Src.Entities;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using System;
using Microsoft.Xna.Framework.Graphics;
using Alpha_Danmaku_Rush_Demo.Src.Utils;
using System.Reflection.Metadata;
using Microsoft.Xna.Framework.Content;

namespace Alpha_Danmaku_Rush_Demo.Src.Managers;

public class CollisionManager
{
    private Player player;
    private List<Bullet> bullets;
    private EnemyManager enemies;
    private ScoreManager score;
    private Texture2D gameOver;

    public CollisionManager(Player player, EnemyManager enemies, ScoreManager score)
    {
        this.player = player;
        this.enemies = enemies;
        this.score = score;
/*        gameOver = content.Load<Texture2D>("GameOver");*/
    }

    public void Update()
    {
        List<Enemy> isActiveEnemies = enemies.ActiveEnemiesList();
        List<Rectangle> isActiveBullets = player.ActiveBulletList();
        CheckEnemyBulletPlayerCollisions();
        CheckEnemyPlayerCollisions();
        CheckPlayerHealth();
        CheckEnemyCollisions(isActiveBullets, isActiveEnemies);
    }

    // Enemies take damage when they collide with bullets
    private void CheckEnemyCollisions(List<Rectangle> bulletBoundingBoxes, List<Enemy> activeEnemies)
    {
        foreach (var enemy in activeEnemies)
        {
            foreach (var bulletBox in bulletBoundingBoxes)
            {
                if (bulletBox.Intersects(enemy.BoundingBox))
                {
                    enemy.TakeDamage(1);
                }
            }
        }

        if (enemies.midBoss != null && enemies.midBoss.isActive)
        {
            foreach (var bulletBox in bulletBoundingBoxes)
            {
                if (bulletBox.Intersects(enemies.midBoss.BoundingBox))
                {
                    enemies.midBoss.TakeDamage(1);
                }
            }
        }
    }

    private void CheckEnemyBulletPlayerCollisions()
    {
        foreach (var bullet in enemies.enemies.SelectMany(enemy => enemy.bulletList.Where(bullet => bullet.BoundingBox.Intersects(player.BoundingBox) && bullet.IsActive)))
        {
            if (!player.IsInvincible) // Check if player is not invincible
            {
                player.Health -= bullet.Damage;
                player.SetInvincibility(5f); // Set invincibility for 5 seconds
                // Respawn the player to the bottom center of the screen
                player.Position = new Vector2((800 - player.Sprite.Width) / 2, 1000 - player.Sprite.Height);
                ClearAllBullets(); // Clear all bullets on the screen
            }
            bullet.IsActive = false;
        }
    }

    private void CheckEnemyPlayerCollisions()
    {
        foreach (var enemy in enemies.enemies.Where(enemy =>
                     enemy.BoundingBox.Intersects(player.BoundingBox) && enemy.isActive))
        {
            
            enemy.Deactivate();
        }
    }

    private void ClearAllBullets()
    {
        foreach (var enemy in enemies.enemies)
        {
            foreach (var bullet in enemy.bulletList)
            {
                bullet.IsActive = false;
            }
        }
    }

    private void CheckPlayerHealth()
    {
        if (player.Health <= 0)
        {
            ExitGame();
        }
    }

    private void ExitGame()
    {
        // Need add more necessary logic before exiting the game
        // saving the player's score
        Environment.Exit(0);
    }
}