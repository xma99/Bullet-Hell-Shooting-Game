﻿using Alpha_Danmaku_Rush_Demo.Src.Utils;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Alpha_Danmaku_Rush_Demo.Src.Entities
{
    public class Player
    {
        // Player default setting
        public Texture2D Sprite;
        public Vector2 Position { get; set; }
        private float playerSpeed = 5.0f;

        public int Health { get; set; } = 5;  // Player health

        // Player invincible time
        private bool isInvincible = false;
        private float invincibilityDuration = 5.0f;
        private float invincibilityTimer = 0.0f;

        // Player shot
        private List<Attack> bullets = new List<Attack>();

        public bool IsInvincible // Correct property name
        {
            get { return isInvincible; }
            private set { isInvincible = value; } // Make sure it can only be set internally
        }

        public Rectangle BoundingBox => new Rectangle((int)Position.X, (int)Position.Y, Sprite.Width, Sprite.Height);

        public Player(Texture2D img, Vector2 initialPosition)
        {
            Sprite = img;
            Position = initialPosition;
        }

        public void Update(GameTime gameTime, int screenWidth, ContentManager content)
        {
            Vector2 movement = Vector2.Zero;
            KeyboardState direction = Keyboard.GetState();

            // Player movement, WASD
            if (direction.IsKeyDown(Keys.W) || direction.IsKeyDown(Keys.Up))
            {
                movement.Y -= 1;
            }
            if (direction.IsKeyDown(Keys.S) || direction.IsKeyDown(Keys.Down))
            {
                movement.Y += 1;
            }
            if (direction.IsKeyDown(Keys.A) || direction.IsKeyDown(Keys.Left))
            {
                movement.X -= 1;
            }
            if (direction.IsKeyDown(Keys.D) || direction.IsKeyDown(Keys.Right))
            {
                movement.X += 1;
            }

            // Speed change
            if (Keyboard.GetState().IsKeyDown(Keys.LeftShift))
            {
                playerSpeed /= 2;
            }
            if (Keyboard.GetState().IsKeyUp(Keys.LeftShift))
            {
                playerSpeed *= 2;
            }

            if (movement.LengthSquared() > 0)
            {
                movement.Normalize();
            }

            // Bullet
            if (Keyboard.GetState().IsKeyDown(Keys.L))
            {
                PlayerAttack(content);
            }

            foreach (var bullet in bullets)
            {
                bullet.UpdateAttack(gameTime);
            }
            bullets.RemoveAll(b => !b.checkAttack);

            // Player can move up but not beyond the width of the screen
            Vector2 updatePosition = Position + movement * playerSpeed;
            updatePosition.X = MathHelper.Clamp(updatePosition.X, 0, screenWidth - Sprite.Width);
            Position = updatePosition;
            playerSpeed = 5.0f;

            // Invincible
            if (isInvincible)
            {
                invincibilityTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (invincibilityTimer <= 0)
                {
                    isInvincible = false;
                }
            }
        }

        private void PlayerAttack(ContentManager content)
        {
            // Create new bullet and movement, the bullet will move upward
            var playerBullet = new Attack(content);
            playerBullet.CreateBullet(new Vector2(Position.X + Sprite.Width / 2 - playerBullet.PlayerBullet.Width / 2, Position.Y - 30));
            playerBullet.BulletVelocity = new Vector2(0, -2);
            bullets.Add(playerBullet);
        }

        // Get the collision PlayerBulletBoundingBoxes of the active bullet
        public List<Rectangle> ActiveBulletList()
        {
            List<Rectangle> bullet_list = new List<Rectangle>();
            foreach (var attack in bullets)
            {
                bullet_list.AddRange(attack.PlayerBulletBoundingBoxes());
            }
            return bullet_list;
        }
        public void SetInvincibility(float duration)
        {
            isInvincible = true;
            invincibilityTimer = duration;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Sprite, Position, Color.White);

            foreach (var bullet in bullets)
            {
                bullet.Draw(spriteBatch);
            }
        }
    }
}
