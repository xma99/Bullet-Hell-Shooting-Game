﻿using Alpha_Danmaku_Rush_Demo.Src.Utils;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Linq;
using System;
using Microsoft.Xna.Framework.Content;
using System.Collections.Generic;

namespace Alpha_Danmaku_Rush_Demo.Src.Entities.Enemies
{
    class SpawnEnemyF : Enemy
    {
        private float finalBossMove = 20f;

        public SpawnEnemyF(ContentManager content, Vector2 startPosition, float movementSpeed) 
            : base(content, startPosition, movementSpeed, 5)
        {
            Sprite = content.Load<Texture2D>("finalBoss");
        }

        public override void Update(GameTime gameTime, Vector2 playerPosition)
        {
            // Implement specific update logic for FinalBossEnemy
            // FinalBoss do left-right movement
            float delta = finalBossMove * (float)Math.Sin(gameTime.TotalGameTime.TotalSeconds * 0.5);
            Position = new Vector2(Position.X + delta, Position.Y);
        }

        public override void Attack(GameTime gameTime, Vector2 playerPosition)
        {
            // Implement specific attack logic for RegularAEnemy
            // RegularAEnemy shoots bullets at the player
            if (gameTime.TotalGameTime.TotalMilliseconds % 500 < 10)
            {
                Vector2 direction = Vector2.Normalize(playerPosition - Position);
                Vector2 bulletVelocity = direction * 8f;
            }
        }

        public static bool ShowFinalBoss(TimeSpan gameTimeElapsed)
        {
            return gameTimeElapsed >= TimeSpan.FromSeconds(92);
        }

        public static SpawnEnemyF Create(ContentManager content, int screenWidth)
        {
            Texture2D finalBossSprite = content.Load<Texture2D>("finalBoss");
            Vector2 spawnPosition = new Vector2((screenWidth / 2) - (finalBossSprite.Width / 2), 0);
            float finalBossSpeed = 3.0f; // Adjust enemy speed as needed
            return new SpawnEnemyF(content, spawnPosition, finalBossSpeed);
        }

        public static void Update(GameTime gameTime, List<Enemy> enemies, ContentManager content, int screenWidth)
        {
            TimeSpan createTime = gameTime.TotalGameTime;

            if (ShowFinalBoss(createTime) && !enemies.OfType<SpawnEnemyF>().Any())
            {
                enemies.Add(Create(content, screenWidth));
            }
        }
    }
}