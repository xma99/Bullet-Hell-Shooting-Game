﻿using Alpha_Danmaku_Rush_Demo.Src.Utils;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Alpha_Danmaku_Rush_Demo.Src.Entities.Enemies
{
    class SpawnEnemyM : Enemy
    {
        private float midBossMove = 20f;

        public SpawnEnemyM(ContentManager content, Vector2 startPosition, float movementSpeed)
            : base(content, startPosition, movementSpeed, 5)
        {
            Sprite = content.Load<Texture2D>("midBoss");
        }

        public override void Update(GameTime gameTime, Vector2 playerPosition)
        {
            // Implement specific update logic for MidBossEnemy
            // MidBoss do left-right movement
            float delta = midBossMove * (float)Math.Sin(gameTime.TotalGameTime.TotalSeconds * 0.5);
            Position = new Vector2(Position.X + delta, Position.Y);
        }

        public override void Attack(GameTime gameTime, Vector2 playerPosition)
        {
            // Implement specific attack logic for RegularAEnemy
            // RegularAEnemy shoots bullets at the player
            if (gameTime.TotalGameTime.TotalMilliseconds % 500 < 10)
            {
                Vector2 direction = Vector2.Normalize(playerPosition - Position);
                Vector2 bulletVelocity = direction * 8f;
            }
        }

        public static bool showMidBoss(TimeSpan gameTimeElapsed)
        {
            return gameTimeElapsed >= TimeSpan.FromSeconds(48) && gameTimeElapsed <= TimeSpan.FromSeconds(75);
        }

        public Rectangle BoundingBox => new Rectangle((int)Position.X, (int)Position.Y, Sprite.Width, Sprite.Height);
        public static SpawnEnemyM Create(ContentManager content, int screenWidth)
        {
            Texture2D midBossSprite = content.Load<Texture2D>("midBoss");
            Vector2 spawnPosition = new Vector2((screenWidth / 2) - (midBossSprite.Width / 2), 0);
            float midBossSpeed = 3.0f; // Adjust enemy speed as needed
            return new SpawnEnemyM(content, spawnPosition, midBossSpeed);
        }

        public static void Update(GameTime gameTime, List<Enemy> enemies, ContentManager content, int screenWidth)
        {
            TimeSpan createMidBoss = gameTime.TotalGameTime;

            if (showMidBoss(createMidBoss) && !enemies.OfType<SpawnEnemyM>().Any())
            {
                enemies.Add(Create(content, screenWidth));
            }
        }
    }
}